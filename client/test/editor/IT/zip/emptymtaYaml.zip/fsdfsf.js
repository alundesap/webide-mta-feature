sap.ui.define([
	"sap/ui/test/opaQunit"
], function(opaTest) {
	"use strict";

	QUnit.module("moduleName");

	opaTest("Should TestDesctiption", function(Given, When, Then) {
		Given.iStartTheAppAction();

		When.onMyPageUnderTest.iDoMyAction();

		Then.onMyPageUnderTest.iDoMyAssertion();
	});

});