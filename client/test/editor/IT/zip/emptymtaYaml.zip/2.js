var x = 3;
var y = 4;
x = y;

function testAdd( x, y) {
	x = 1;
	return x + y;
}

function testMultiply( x, y) {
	x = 1;
	return x * y;
}