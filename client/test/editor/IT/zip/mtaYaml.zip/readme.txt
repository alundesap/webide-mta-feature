 #### WELCOME ####

This is your copy of the SAPUI5 Master-Detail Freestyle Application Template.
You can find the template version in the .project.json - file in your workspace

For a detailed version change log, take a look at this page:

==  https://jam4.sapjam.com/search/universal_search2?query=&sort=score&tag=sapui5_freestyle_application_templates  ==

For more information please visit the Fiori Technology wiki for details about the freestyle architecture:

==  https://wiki.wdf.sap.corp/wiki/display/fioritech/Freestyle+Applications  ==

Please report bugs using BCP to component CA-UI5-DOC

This template will not be updated automatically! But we will provide fixes for hands-on adaption.
For notifications on updates and fixes we highly recommend subscribing to this email list:

==  DL PI Tech UI - UI5 Freestyle Applications  ==

Template Documentation can be found in the demokit here:
http://veui5infra.dhcp.wdf.sap.corp:8080/demokit/#docs/guide/a460a7348a6c431a8bd967ab9fb8d918.html


 #### Happy Development! ####